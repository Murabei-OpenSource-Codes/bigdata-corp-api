# bigdata-corp-api
Python API to facilitate interaction with BigDataCorp end-points
